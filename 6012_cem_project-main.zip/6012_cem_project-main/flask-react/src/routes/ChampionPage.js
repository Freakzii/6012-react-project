import './ChampionPage.css';

import React, { useEffect, useState } from 'react';
import { Grid,Segment,Image,Container, Card} from 'semantic-ui-react'
import { useParams} from "react-router-dom";

import { Builds } from "../components/Builds";
import { BuildForm } from "../components/BuildForm";
import { RecommendedBuild } from "../components/RecommendedBuild";
import { BuildsNav } from "../components/BuildsNav";
import { ChampionInfo, ChampionCard } from "../components/ChampionInfo";
import { MenuExampleBasic } from "../components/Nav";
//page for each indvidual champ
export const ChampionPage = () => {
    let { id } = useParams()
    
    const [champion, setChampion] = useState([]);
    const [builds, setBuilds] = useState([]);
    const [abilities, setAbilities] = useState([]);
    const [skins, setSkins] = useState([]);
    
    useEffect(()=> {
        /* Champion data */
        fetch('https://congo-samuel-5000.codio-box.uk/champions/' + (id).toString(), {
            credentials: 'include' 
        }).then(response => response.json().then(data => {
            setChampion(data.champion)
            console.log(data.champion)
        }))
        /* Builds for champion data */
        fetch('https://congo-samuel-5000.codio-box.uk/builds/' + (id).toString(), {
            credentials: 'include' 
        }).then(response => response.json().then(data => {
            setBuilds(data.builds)
            console.log(data.builds)
        }))
        /* Abilities for champion data */
        fetch('https://congo-samuel-5000.codio-box.uk/abilities/' + (id).toString(), {
            credentials: 'include' 
        }).then(response => response.json().then(data => {
            setAbilities(data.abilities)
            console.log(data.abilities)
        }))
        /* Skins for champion data */
        fetch('https://congo-samuel-5000.codio-box.uk/skins/' + (id).toString(), {
            credentials: 'include' 
        }).then(response => response.json().then(data => {
            setSkins(data.skins)
            console.log(data.skins)
        }))
	},[])

    return (
        <div className="Info">
            <MenuExampleBasic/>
           
             <ChampionInfo champion = { champion } abilities = { abilities } skins = { skins }/>
            <Grid Columns={1}>
                <Grid.Column>
                    <Segment>
                        <h1>Builds</h1>
                    </Segment>
                </Grid.Column>
            </Grid>

             <Segment>
                 <BuildsNav/>

                <RecommendedBuild build = { builds[0] }/>

                <BuildForm/>

                <Builds builds={builds}/>
             </Segment>
           
        </div>
    )
}
//champions cards are displayed from the componets on this page
export const ChampionsPage = () => {
    let { id } = useParams()
    const [champions, setChampions] = useState([])
    
    useEffect(()=> {
        fetch('https://congo-samuel-5000.codio-box.uk/champions', { credentials: 'include' })
            .then(response => response.json().then(data => {
            setChampions(data.champs)
            console.log(data.champs)
        }))
	},[])

    return (
        
        <div className="Info">
            <MenuExampleBasic/>
        <h1 >Champions!</h1>
        <h3 >Please pick a Champion</h3>
       
        <Card.Group itemsPerRow ={3} centered>
            <ChampionCard champions = {champions}/>
        </Card.Group>
        
        
        </div>
    )
}
