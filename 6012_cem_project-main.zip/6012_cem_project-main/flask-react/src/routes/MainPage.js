
import './MainPage.css';

import React, {useEffect, useState} from 'react';
import { Grid,Segment,Image,Card} from 'semantic-ui-react'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import { Builds } from "../components/Builds";
import { BuildForm } from "../components/BuildForm";
import { MenuExampleBasic } from "../components/Nav";

import { BuildsNav } from "../components/BuildsNav";
import { RecommendedBuild } from "../components/RecommendedBuild";
// landing page
export const MainPage = () => { 
    const [builds, setBuilds] = useState([]);
            useEffect(()=> {
			fetch('https://congo-samuel-5000.codio-box.uk/builds', {
                credentials: 'include' 
            }).then(response => response.json().then(data => 
                {setBuilds(data.builds);
			})
        )
	},[])
    
    const divStyle = {
      color: 'red'
    }

	return (
		<div className="App">
            <MenuExampleBasic/> 	        
                <Image className="center" src='./images/title.png'/>  
            <h2>Please select a section!</h2>
        <Grid columns={3}>
                <Grid.Column>
                  <Card fluid >
                   
                    <Card.Content>
                      <Card.Header>
                      <Image width="700" height="400" src='./images/champs.jpg'/> 
                      <h1>
                          <Link to="/champions">Champions</Link>
                       </h1>         
                    </Card.Header>
                   </Card.Content> 
                  </Card>
                </Grid.Column>
            <Grid.Column>
            <Card fluid>
                   
                    <Card.Content>
                      <Card.Header>
                      <Image width="700" height="400" src='./images/esports.jpg'/> 
                      <h1>
                          <Link to="/Esports">E-Sports</Link>
                       </h1>         
                    </Card.Header>
                   </Card.Content> 
                  </Card>
            </Grid.Column>                 
            <Grid.Column>
            <Card fluid>
                   
                    <Card.Content>
                      <Card.Header>
                      <Image width="700" height="400" src='./images/news.jpg'/> 
                      <h1>
                          <Link to="/news">News</Link>
                       </h1>         
                    </Card.Header>
                   </Card.Content> 
                  </Card>
            </Grid.Column>
            </Grid>

           
        </div>
	)
}
