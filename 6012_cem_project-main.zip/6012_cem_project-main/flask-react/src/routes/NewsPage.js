import './MainPage.css';

import React, {useEffect, useState} from 'react';
import { Grid,Segment,Image,Card} from 'semantic-ui-react'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import { MenuExampleBasic } from "../components/Nav";
import { NewsTabs } from "../components/NewsTabs";
export const NewsPage = () => { 
    
   //news page 
  
	return (
		<div className="Info">
        <MenuExampleBasic/>
        <h1 className = 'red_text'>News!</h1>
        <h3 className = 'red_text'>Please pick a artical to read!</h3>
        <NewsTabs/>
	</div>
    )
}
