import './MainPage.css';

import React, {useEffect, useState} from 'react';
import { Grid,Segment,Image,Card} from 'semantic-ui-react'
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import { MenuExampleBasic } from "../components/Nav";
import { EsportsTabs } from "../components/EsportsTabs";
//esports page
export const EsportsPage = () => { 
      
  
	return (
		<div className="Info">
        <MenuExampleBasic/>
        <h1 class="red_text">E-sports!</h1>
        <h3 class="red_text">Please pick a Region</h3>
        <EsportsTabs/>
        
        </div>
    
    )
}