import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'

import { MainPage } from "./routes/MainPage";
import { ChampionPage, ChampionsPage } from "./routes/ChampionPage";
import { NewsPage } from "./routes/NewsPage";
import { EsportsPage } from "./routes/EsportsPage";
//where all pages are defined
function App() { 
    return (
        <Router>
            <Routes>
                <Route 
                    path = '/'
                    element = { <MainPage /> }
                />
                <Route 
                    path = '/champions/:id'
                    element = { <ChampionPage /> }
                />
            <Route 
                    path = '/champions'
                    element = { <ChampionsPage /> }
                />
             
           <Route 
                    path = '/news'
                    element = { <NewsPage /> }
                />
            <Route 
                    path = '/Esports'
                    element = { <EsportsPage /> }
                />
             </Routes>
            
        </Router>
    )
}

    
    


export default App;
