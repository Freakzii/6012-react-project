

import React from 'react';
import { Grid, Image, Tab } from 'semantic-ui-react'
 //gets the link for the id and then makes ammount of tabs needed to fit all videos in
export const Skins = ({ skins }) => {
    if ( typeof skins != "undefined" ) {             
        const tabs2 = skins.map(skin => {
            const link = 'https://www.youtube.com/embed/' + skin.yt_id
            return {
                menuItem: skin.name, render: () => (
                    <Tab.Pane> 
                        <iframe 
                            width="550" 
                            height="300" 
                            src= {link}
                            title= {skin.name}
                            frameborder="0" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </Tab.Pane>)
            }
        })

        return (
            
            <Tab panes={tabs2} />
        
    )
    } else {
        return null
    }
}