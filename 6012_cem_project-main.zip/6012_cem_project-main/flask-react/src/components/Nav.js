import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import React from 'react';
import { Menu,Icon,Dropdown } from 'semantic-ui-react'


  
export const MenuExampleBasic = () =>  {
  
//all routes for all pages in the top navigation bar
    return (
      <Menu>
        <Menu.Item >
            <Icon name='gamepad' />
               <Link to="/"><h2>League of Builds</h2></Link>
        </Menu.Item>
        <Menu.Item >
            <Icon name='copy' />
            <Link to="/champions">Champions</Link>
        </Menu.Item>
        <Menu.Item>
            <Icon name='fighter jet' />
            <Link to="/Esports">E-sports</Link>
        </Menu.Item>
        <Menu.Item>
            <Icon name='bell' />
            <Link to="/news">News</Link>       
        </Menu.Item>
      </Menu>
    )
  }
