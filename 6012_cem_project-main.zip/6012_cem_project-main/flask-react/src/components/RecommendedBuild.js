import React from 'react';
import {Grid } from "semantic-ui-react";
//shows recomeneded build
export const RecommendedBuild = ({ build }) => {
    if ( typeof build != "undefined" ) {
        return (
            <div>
                <Grid Columns={1}>
                    <Grid.Column>
                        <h3>Recommended Build</h3>
                    </Grid.Column>
                </Grid>
                <Grid columns={6} >
                    <Grid.Column>
                        <h3>{ build.mythic }</h3>
                    </Grid.Column>
                    <Grid.Column>
                        <h3>{ build.starter }</h3>
                    </Grid.Column>
                    <Grid.Column>
                        <h3>{ build.rune1 }</h3>
                    </Grid.Column>
                    <Grid.Column>
                        <h3>{ build.rune2 }</h3>
                    </Grid.Column>
                    <Grid.Column>
                        <h3>{ build.summoner1 }</h3>
                    </Grid.Column>
                    <Grid.Column>
                        <h3>{ build.summoner2 }</h3>
                    </Grid.Column>
                </Grid>
            </div>
        )
    } else {
        return null
    }
}