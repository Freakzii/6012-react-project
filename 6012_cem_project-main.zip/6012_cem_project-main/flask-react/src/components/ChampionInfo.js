
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'
import React from 'react';
import { Grid, Image,Card,Segment,Button } from 'semantic-ui-react'
import { Abilities } from "../components/Abilities";
import { Skins } from "../components/Skins";
  //store champions info, images and videos as one component 
export const ChampionInfo = ({ champion, abilities, skins }) => {
    if ( typeof champion != "undefined" && typeof abilities != "undefined") {
        console.log(champion)
        const imgPath = `/images/${champion.name}.jpg`
        return (
            <div>
                <Grid columns={2} >
                    <Grid.Column>
                       <Segment> <h1>{ champion.name }</h1></Segment>
                       
                        <Image className="center" src={ imgPath } alt="user-avatar" width="750" height="200" />
                        <div> <Link to="/champions"><Button>All Champions</Button></Link></div>
                    </Grid.Column>
                    <Grid.Column>
                   <Segment><h1>Skins</h1></Segment>
                            <Skins skins={skins} />
                    </Grid.Column>           
                </Grid>
<Segment><h1>Abilities</h1></Segment>
                <Abilities abilities= {abilities}/>
            </div>
        )
    } else {
        return null
    }
}
  
   
export const ChampionCard = ({ champions }) => {
    if ( champions != []) {
        console.log(champions)
        const items = champions.map(champion => {
            const imgPath = `/images/${champion.name}.jpg`
            const link = `/champions/${champion.id}`
            return (
                    <Card fluid>
                   
                    <Card.Content >
                      <Card.Header>
                      <h1 className = 'red_text'>
                          { champion.name }
                       </h1>
                <Image className="center" src={ imgPath } alt="user-avatar" width="300" height="200" />
                
                    </Card.Header>
                   </Card.Content>
                    <Card.Content extra>
                        <Link to={link}><h3>View</h3></Link>
                        
                    </Card.Content>
                  </Card>  
                )
        })
        return items
            
            
    } else {
        return null
    }
} 
 