import React from 'react';
import { Grid, Segment } from "semantic-ui-react";
//navigation for builds form
export const BuildsNav = () =>  {
    return(
        <div>
            <Grid columns={6} >
                <Grid.Column>
                    <h1>Mythic</h1>
                </Grid.Column>
                <Grid.Column>
                    <h1>Starter</h1>
                </Grid.Column>
                <Grid.Column>
                    <h1> Rune 1</h1>
                </Grid.Column>
                <Grid.Column>
                    <h1>  Rune 2</h1>
                </Grid.Column>
                <Grid.Column>
                    <h1> Summoner 1</h1>
                </Grid.Column>
                <Grid.Column>
                    <h1> Summoner 2</h1>
                </Grid.Column>
            </Grid>
        </div>
        )
    }