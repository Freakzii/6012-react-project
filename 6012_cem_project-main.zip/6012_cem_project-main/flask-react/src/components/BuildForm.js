import './components.css';
import React, {useState} from 'react';
import { Dropdown, Button, Grid, Form} from 'semantic-ui-react'
import { useParams } from "react-router-dom";
 //used to create form in champions page    
const OptionsMythic = [
  
   {
    key: 'Divine Sunderer',
    text: 'Divine Sunderer',
    value: 'Divine Sunderer',
  },
  {
    key: 'Liandrys Anguish',
    text: 'Liandrys Anguish',
    value: 'Liandrys Anguish',
  },
{
    key: 'Moonstone Renewer',
    text: 'Moonstone Renewer',
    value: 'Moonstone Renewer',
  },
{
    key: 'Night Harvester',
    text: 'Night Harvester',
    value: 'Night Harvester',
  },
  {
    key: 'Everfrost',
    text: 'Everfrost',
    value: 'Everfrost',
  },
{
    key: 'Frostfire Gauntlet',
    text: 'Frostfire Gauntlet',
    value: 'Frostfire Gauntlet',
  },
{
    key: 'Galeforce',
    text: 'Galeforce',
    value: 'Galeforce',
  },
{
    key: 'Sunfire Aegis',
    text: 'Sunfire Aegis',
    value: 'Sunfire Aegis',
  }
]
const OptionsStarter = [
  {
    key: 'Dorans ring',
    text: 'Dorans ring',
    value: 'Dorans ring',
  },
  {
    key: 'Dorans shield',
    text: 'Dorans shield',
    value: 'Dorans shield',
  },
{
    key: 'Emberknifer',
    text: 'Emberknifer',
    value: 'Emberknifer',
  },
{
    key: 'Hailblade',
    text: 'Hailblade',
    value: 'Hailblade',
  },
  {
    key: 'Cull',
    text: 'Cull',
    value: 'Cull',
  },
{
    key: 'Dark Seal',
    text: 'Dark Seal',
    value: 'Dark Seal',
  },
{
    key: 'Spellthiefs Edge',
    text: 'Spellthiefs Edge',
    value: 'Spellthiefs Edge',
  },
{
    key: 'Relic Shield',
    text: 'Relic Shield',
    value: 'Relic Shield',
  },
]
const OptionsRune1 = [
  {
    key: 'Precision',
    text: 'Precision',
    value: 'Precision',
  },
  {
    key: 'Sorcery',
    text: 'Sorcery',
    value: 'Sorcery',
  },
{
    key: 'Domination',
    text: 'Domination',
    value: 'Domination',
  },
{
    key: 'Resolve',
    text: 'Resolve',
    value: 'Resolve',
  },
  {
    key: 'Inspiration',
    text: 'Inspiration',
    value: 'Inspiration',
  }

]
const OptionsRune2 = [
  {
    key: 'Precision',
    text: 'Precision',
    value: 'Precision',
  },
  {
    key: 'Sorcery',
    text: 'Sorcery',
    value: 'Sorcery',
  },
{
    key: 'Domination',
    text: 'Domination',
    value: 'Domination',
  },
{
    key: 'Resolve',
    text: 'Resolve',
    value: 'Resolve',
  },
  {
    key: 'Inspiration',
    text: 'Inspiration',
    value: 'Inspiration',
  }

]
const OptionsSummoner1 = [
  {
    key: 'Heal',
    text: 'Heal',
    value: 'Heal',
  },
  {
    key: 'Ghost',
    text: 'Ghost',
    value: 'Ghost',
  },
{
    key: 'Barrier',
    text: 'Barrier',
    value: 'Barrier',
  },
{
    key: 'Exhaust',
    text: 'Exhaust',
    value: 'Exhaust',
  },
  {
    key: 'Flash',
    text: 'Flash',
    value: 'Flash',
  },
{
    key: 'Teleport',
    text: 'Teleport',
    value: 'Teleport',
  },
{
    key: 'Smite',
    text: 'Smite',
    value: 'Smite',
  },
{
    key: 'Cleanse',
    text: 'Cleanse',
    value: 'Cleanse',
  },
  {
    key: 'Ignite',
    text: 'Ignite',
    value: 'Ignite',
  }
]
export const BuildForm = () => {
    let { id } = useParams()
    
    const [buildObject, setBuildObject] = useState({champion_id: id, mythic: '', starter: '', rune1: '', rune2: '', summoner1: '', summoner2: ''})
    function refreshPage() {
    window.location.reload(false);
  }
    const handleMythicChange = (value) => {
        const build = buildObject
        build.mythic = value
        setBuildObject(build)
    } 
     const handleStarterChange = (value) => {
        const build = buildObject
        build.starter = value
        setBuildObject(build)
    }   
     const handleRune2Change = (value) => {
        const build = buildObject
        build.rune1 = value
        setBuildObject(build)
    }
     const handleRune1Change = (value) => {
        const build = buildObject
        build.rune2 = value
        setBuildObject(build)
    }  
     const handleSummoner1Change = (value) => {
        const build = buildObject
        build.summoner1 = value
        setBuildObject(build)
    }
     const handleSummoner2Change = (value) => {
        const build = buildObject
        build.summoner2 = value
        setBuildObject(build)
    }  
    return (
        <Form>
            <Grid columns={6} >
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Mythic Item'
                        selection
                        onChange={ (e, d) => handleMythicChange(d.value) }
                        options={OptionsMythic}
                    />
                </Grid.Column>
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Starter Item'
                        selection
                        onChange={ (e, d) => handleStarterChange(d.value) }
                        options={OptionsStarter}
                    />   
                </Grid.Column>
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Main Rune'
                        selection
                        onChange={ (e, d) => handleRune1Change(d.value) }
                        options={OptionsRune1}
                    />   
                </Grid.Column>
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Secondary Rune'
                        selection
                        onChange={ (e, d) => handleRune2Change(d.value) }
                        options={OptionsRune2}
                    />   
                </Grid.Column>
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Summoner 1'
                        selection
                        onChange={ (e, d) => handleSummoner1Change(d.value) }
                        options={OptionsSummoner1}
                    />   
                </Grid.Column>
                <Grid.Column>
                    <Form.Select
                        placeholder='Select Summoner 2'
                        selection
                        onChange={ (e, d) => handleSummoner2Change(d.value) }
                        options={OptionsSummoner1}
                    />   
                </Grid.Column>
            </Grid>
            <Grid Columns ={1}>
                <Grid.Column>
                    <Button className="App"  
                   
                    onClick={ async () => {
                        console.log(buildObject)
                        const response = await fetch('https://congo-samuel-5000.codio-box.uk/add_build', {
                            method: 'POST',
                            credentials: 'include',
                            headers: {
                                'Content-type': 'application/json'
                            },
                            body: JSON.stringify(buildObject)
                            
                        })
                        if (response.ok){
                            console.log('response worked!')
                            window.location.reload();

                        }
                    }}
                    content='Submit'
                 />
            </Grid.Column>
        </Grid>
    </Form>
    )
}
