import React from 'react';
import { List, Grid } from "semantic-ui-react";
//displayed builds data for each champions 
export const Builds = ({ builds }) => {
	return (
		<List>
			{builds.map(build => {
				return (
					
                 <List.Item key={build.rune1}>
      
        <Grid columns={6} >
      <Grid.Column className="tabs">
        	{build.mythic}
      </Grid.Column>
      <Grid.Column className="tabs1">
          {build.starter}
      </Grid.Column>
      <Grid.Column className="tabs">
     {build.rune1}
      </Grid.Column>
      <Grid.Column className="tabs1">
             {build.rune2}
        </Grid.Column>
     <Grid.Column className="tabs">
    {build.summoner1 }
        </Grid.Column>
    <Grid.Column className="tabs1">
    {build.summoner2}
        </Grid.Column>

</Grid>
                        
                    </List.Item>
					
                    )
				})}
		</List>
	)
}
