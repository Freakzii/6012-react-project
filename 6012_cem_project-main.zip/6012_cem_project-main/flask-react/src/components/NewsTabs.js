import React, {useEffect, useState} from 'react';
import { Tab,Image} from 'semantic-ui-react'


//all new articals on news tabs
export const NewsTabs = () => { 
    
    
  
	
		
    const tabs = [
        { menuItem: 'Challanges coming to PBE', render: () => <Tab.Pane>
         <h1 className = 'red_text'>Challanges coming to PBE</h1>
         <p>We've talked about the Challenges system a few times over the past couple of months, and it's about to hit PBE! Challenges are designed to provide meaningful progression to all League players—so not just Ranked ravagers, but ARAM aficionados, Clash contenders, and cosmetic collectors too. 

Challenges are a little different than the one-and-done achievement systems you might be used to. You can level up individual challenges from Iron all the way to Master. And if that’s not enough, once you’ve hit Master, many challenges also have their own Grandmaster and Challenger tiers. And just like in Ranked, only a certain number of players per region can be in these tiers at any given time. If you’ve ever wanted to be known as the person with the most pentakills on the server this is your chance.

We’ll be launching with over 300 challenges, so they'll be taking an extended stay on PBE to test everything out before going live in early 2022. Because Challenges has a lot going on, some features will hit PBE later than others, but we're sharing a full runthrough today so you know what to expect over the next few months.</p>
         <p>Challenges have their own tab within your profile. You'll also be able to look up other players to check out their Challenges progress, too.

The big crystal on the left tracks your overall progression through the system. Every challenge you rank up increases your overall score, and over time, your crystal evolves from—you guessed it—Iron to Challenger. 

The five bars beneath your crystal represent the five* categories of challenges. Categories are a middle ground between your overall progress and individual challenges, letting you track your growth along particular aspects of the game. And (surprise!) they rank up as well.

</p> 
        <Image className="center" width="200" height="400" src='./images/esports.jpg'/>
        <p>Imagination: Modes and innovative plays make this category the home for those who dare to dream
Bad Medicine: Kill enemies recently healed by a heal pack in ARAM
Wave Goodbye: Kill 20 minions within 3 Seconds
Expertise: Skillfully crushing your opponents is the way to earn big in this category
Unkillable Demon King: Win games without dying
Flame Horizon: Win games with 100 or more CS than your opponent
Teamwork & Strategy: Working together with your team to dominate the Rift is the focus here
Soul Sweep: Claim Dragon Souls 4 - 0
Team Diff: Score aces between minion spawn and 15 minutes
Veterancy: Putting up big lifetime numbers in kills, gold earned, and other stats will help boost this bucket
PENTAKIIIIIIIIL!!: Get Pentakills
Multi-Weapon Master: Win with different Mythic Items
Collection: It's in the name. Collecting cosmetics and engaging in loot fills the bars here
Icon of the Rift: Obtain Summoner Icons
Spice of Life: Obtain Champions
*Legacy: Time-limited challenges live in this category to commemorate past achievements others can no longer obtain. They don't contribute to your overall progress, nor can you level up Legacy as a category.
There's a search bar in the Challenges tab that'll let you find any challenge by its name or the criteria it tracks. You can also filter challenges within each category by group (ex. ARAM within Imagination), most recently ranked up, or current tier.</p>
         </Tab.Pane> },
        { menuItem: 'TEAMFIGHT TACTICS PATCH 11.22 NOTES', render: () => <Tab.Pane><h1 className = 'red_text'>TEAMFIGHT TACTICS PATCH 11.22 NOTES</h1>Okay, let's talk about titles, Tokens, and all the places where Challenges shows up outside of your profile. For starters, we've updated lobbies to make space for everything Challenges provides.

Your Summoner Icon is still the centerpiece of your identity, but ranked armor has been visually reforged into Ranked Crests. You can still swap between your Ranked and Prestige (level) borders, and you'll finally be able to freely choose between any of the Prestige borders you’ve previously earned, not just the most current. We’ve also added the Challenge Crystal right below your Summoner Icon. Hovering over a player's Summoner Icon will display a tooltip showing current and past rank, Summoner Icon info, and detailed Challenges information including their rank for each of the five categories.

Summoner names are still in the same spot, but they have a new friend right underneath them: Titles.

Titles ("Dragonmaster") are earned by leveling certain challenges to specific tiers, and you can freely choose between any title you've unlocked.

Beneath titles are the Challenge Tokens, which you also saw earlier in the Challenges tab. You can equip up to three to show off. Wherever a Token appears, you'll be able to hover over it to see its associated challenge and Tier.

One notable omission from the new banners is the border trim indicating past rank. We're working on something tentatively named Banner Accents that’ll come out after the initial Challenges launch, which will include past rank. In the meantime, past rank info shows up when you hover over players' Summoner Icons.</Tab.Pane> },
        { menuItem: 'Teams going to worlds 2021', render: () => <Tab.Pane><h1 className = 'red_text'>Teams going to worlds 2021</h1><p>LPL (China)
FunPlus Phoenix (qualified for groups)
EDG (qualified for groups)
RNG (qualified for groups)
LNG
FunPlus Phoenix clinched their first Worlds berth since winning it all in 2019. Their dominant semifinal sweep of WE ensured them a spot in the domestic finals and, at minimum, the highest amount of championship points of any team with 180.

EDG qualified for Worlds 2021 following a convincing win against Team WE in the LPL Summer Split semifinals. With 160 championship points, behind only FPX in the standings, the team advances straight to the group stage of the end-of-year event.


Royal Never Give Up secured China’s third seed at Worlds after beating Team WE in the regional finals, offsetting an early loss to LNG in the LPL Summer Split playoffs.

A win over Team WE in round two of the LPL regional finals assured LNG the fourth and final spot at Worlds 2021. This will be the first time the team has made it to League’s end-of-year event.</p>

<p>
LCK (Korea)
DWG KIA (qualified for groups)
Gen.G (qualified for groups)
T1 (qualified for groups)
Hanwha Life
DWG qualified for Worlds 2021 based on championship points gained over the season. A total of 190 points—90 from the Spring Split and 100 from the Summer Split—secured qualification for the reigning world champions.

Gen.G secured a spot at Worlds 2021 after picking up 150 championship points. A strong performance in the spring and summer regular seasons cushioned the blow for the team’s early exit in the playoffs.


T1 made it to Worlds 2021 despite setbacks throughout the season. A run through the Summer Split playoffs—beating SANDBOX in the quarterfinals and Gen.G in the semis—earned the team 100 championship points, adding to the 30 gained in spring.

A convincing 3-0 win against NS RedForce in the LCK regional finals secured Hanwha Life the final spot at Worlds 2021. Jeong “Chovy” Ji-hoon, arguably one the best mid laners in Korea, and Kim “Deft” Hyuk-kyu, a celebrated veteran in the region, will be returning once again to the international stage.
</p>
<p>
LEC (Europe)
MAD Lions (qualified for groups)
Fnatic (qualified for groups)
Rogue (qualifed for groups)
In a repeat performance of the LEC Spring Split playoffs, MAD Lions beat G2 Esports 3-1 to secure a spot at Worlds 2021. The former LEC champions left much to be desired in the best-of-five series.

Fnatic overcame long-time rivals G2 Esports to earn a spot at Worlds 2021. Gabriël “Bwipo” Rau’s switch from the top lane to the jungle paid dividends in the playoffs.


After placing first in the LEC summer regular season with a 13-5 record, a hard-fought win against Misfits was all Rogue needed to qualify for Worlds 2021.
</p>
 <p>   
LCS (North America)
100 Thieves (qualified for groups)
Team Liquid (qualified for groups)
Cloud9
For the first time since 2018, 100 Thieves qualified for Worlds after beating Evil Geniuses in the LCS Summer Split playoffs. A roster reshuffle in the offseason has made a significant impact on the team.


Team Liquid qualified for Worlds 2021 after a decisive 3-1 win over TSM in the LCS Summer playoffs. The team got it together when it mattered the most, despite issues with health, player management, and coaching staff throughout the split.

A return to form for spring champions Cloud9 saw the team qualify for Worlds 2021 after a narrow 3-2 win against TSM in the loser’s bracket of the Summer Split playoffs. NA’s most storied team will once again represent the region on the world stage.
</p>
<p>
PCS (TW/HK/MC/SEA)
PSG Talon (qualified for groups)
Beyond Gaming
PSG Talon were crowned the PCS champions following a flawless 18-0 run through the summer regular season. A nail-biting 3-2 win against Beyond Gaming in the grand final secured the squad a spot at Worlds 2021.

Beyond Gaming took down reigning champions PSG Talon in the semifinals after overcoming a 2-1 deficit to punch their ticket to Worlds 2021. It is the org’s first Worlds appearance in as many years since acquiring the spot of ahq eSports Club in January.


VCS (Vietnam)
The teams representing Vietnam will no longer be able to attend Worlds 2021. When Riot pivoted the end-of-year tournament from China to Europe, teams from Vietnam were faced with difficulties acquiring the necessary visas. Riot confirmed this in a statement on Sept. 9.

LCL (CIS)
Unicorns of Love
The Unicorns will be returning for their third consecutive Worlds appearance after bouncing back in the LCL Summer Split playoffs. The team, having lost to CrowCrowd in round two, redeemed themselves in the final.</p></Tab.Pane> },
        ]
    
    return (
        
        <Tab menu={{ fluid: true, vertical: true}} panes={tabs} />
    )

        
	
}