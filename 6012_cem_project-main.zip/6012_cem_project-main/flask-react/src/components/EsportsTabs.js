
import React, {useEffect, useState} from 'react';
import { Tab, Grid} from 'semantic-ui-react'


//stores all esports components
export const EsportsTabs = () => { 
    		
    const tabs = [
        { menuItem: 'LCS', render: () => <Tab.Pane>
         <Grid columns={2} className="Info">
            <Grid.Column>
            <h1 className = 'red_text'>Results</h1>
            <Grid columns={3}>
             <Grid.Column className = 'e1' >
            FlyQuest
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           0-2
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               Cloud9
            </Grid.Column>
            <Grid.Column className = 'e1' >
            TSM
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           0-2
            </Grid.Column>
             <Grid.Column className = 'e1'>
            100 Thieves
            </Grid.Column>
            <Grid.Column className = 'e1' >
            Team Liquid
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           2-0
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                Immortals
            </Grid.Column>
            </Grid>

            </Grid.Column>
             <Grid.Column>
            <h1 className = 'red_text'>Upcoming</h1>
             <Grid columns={3}>
             <Grid.Column className = 'e1' >
            Golden Guardians
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                CLG
            </Grid.Column>
            <Grid.Column className = 'e1' >
            Dignitas
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
              Evil Geniuses
            </Grid.Column>
            <Grid.Column className = 'e1' >
            CLG
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               FlyQuest
            </Grid.Column>
            </Grid>


            </Grid.Column>
            </Grid>
         
         
         </Tab.Pane>},
        { menuItem: 'LCK', render: () => <Tab.Pane>
        <Grid columns={2} className="Info">
            <Grid.Column>
            <h1 className = 'red_text'>Results</h1>
            <Grid columns={3}>
             <Grid.Column className = 'e1' >
            Gen.G
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           0-2
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               Liiv SANDBOX
            </Grid.Column>
            <Grid.Column className = 'e1' >
            SKT
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           2-1
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                DWG KIA
            </Grid.Column>
            <Grid.Column className = 'e1' >
            DRX
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           2-0
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                KT Rolster
            </Grid.Column>
            </Grid>

            </Grid.Column>
             <Grid.Column>
            <h1 className = 'red_text'>Upcoming</h1>
             <Grid columns={3}>
             <Grid.Column className = 'e1' >
            Fredit BRION
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                KT Rolster
            </Grid.Column>
            <Grid.Column className = 'e1' >
            SKT
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               Afreeca Freecs
            </Grid.Column>
            <Grid.Column className = 'e1' >
            ECD
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
                Mouz
            </Grid.Column>
            </Grid>


            </Grid.Column>
            </Grid>
        </Tab.Pane>},
        { menuItem: 'LEC', render: () => <Tab.Pane>
            <Grid columns={2} className="Info">
            <Grid.Column>
            <h1 className = 'red_text'>Upcoming</h1>
            <Grid columns={3}>
             <Grid.Column className = 'e1' >
            Rogue
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           0-2
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
             G2 Esports
            </Grid.Column>
            <Grid.Column className = 'e1' >
           MAD Lions
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           0-2
            </Grid.Column>
             <Grid.Column className = 'e1'>
            Misfits Gaming
            </Grid.Column>
            <Grid.Column className = 'e1' >
            Fnatic
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           2-0
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               Team Vitality
            </Grid.Column>
            </Grid>

            </Grid.Column>
             <Grid.Column>
            <h1 className = 'red_text'>Results</h1>
             <Grid columns={3}>
             <Grid.Column className = 'e1' >
            Astralis
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
               Excel
            </Grid.Column>
            <Grid.Column className = 'e1' >
            Dignitas
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            
              SK Gaming
            </Grid.Column>
            <Grid.Column className = 'e1' >
            CLG
            </Grid.Column>
                 <Grid.Column className = 'e2'>
           VS
            </Grid.Column>
             <Grid.Column className = 'e1'>
            Schalke 04
            </Grid.Column>
            </Grid>


            </Grid.Column>
            </Grid>
            </Tab.Pane>},
    ]
    
    return (
        
        <Tab menu={{ fluid: true, vertical: false}} panes={tabs} />
    )

        
	
}