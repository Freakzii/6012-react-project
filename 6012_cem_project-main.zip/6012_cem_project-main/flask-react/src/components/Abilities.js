import React from 'react';
import { Card, Grid,Segment } from "semantic-ui-react";
//used to create the abilite cards in champions page
export const Abilities = ({ abilities }) => {
    if ( typeof abilities != "undefined" ) {
        return (
                   
            <Grid columns={2} >
            { abilities.map(ability => {
                return (
                    
             <Grid.Column>
                        
             <Card fluid >
                            <Card.Content  header= {ability.name} />
                            <Card.Content height="50" description={ability.desc}/>
                            <Card.Content extra>{ability.cost}
                            </Card.Content>
                        </Card>
                    </Grid.Column>
                )
            })}
            </Grid>
        )
    } else {
        return null
    }
}