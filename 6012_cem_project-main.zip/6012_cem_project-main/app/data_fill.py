from flask import Blueprint, jsonify, request
from . import db
from .models import Build, Champion, Ability, Skin
from flask_cors import CORS

data = Blueprint('data', __name__)
CORS(data, supports_credentials=True)
# used to insert champions data
@data.route('/fill')
def fill():
    champ = Champion('Senna')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 1
    
    ability1 = Ability(
        champion_id,
        'Piercing Darkness',
        'ACTIVE: Senna fires a spectral laser in the direction of the target unit, Heal power icon.png healing herself and allied Champion icon.png champions in a line, and dealing physical damage to enemies in a thinner line. The damage applies Life steal icon.png life steal at 100% effectiveness.',
        'COST: 70 / 80 / 90 / 100 / 110 MANA - COOLDOWN: 15'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Last Embrace',
        'ACTIVE: Senna throws a globule of Black Mist in the target direction that deals physical damage to the first enemy hit and sticks onto them for 1 second.',
        'COST: 50 / 55 / 60 / 65 / 70 MANA - COOLDOWN: 11'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Curse of the Black Mist',
        'ACTIVE: Senna surrounds herself with an aura of mist and gains Twitch Ambush 2.png camouflage for a duration. If Senna breaks the camouflage, she regains it after 1.75 seconds of not performing actions that break stealth.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'Dawning Shadow',
        'ACTIVE: Senna Sight icon.png reveals herself before firing two waves of spectral light in the target direction, granting Sight icon.png sight of the area briefly along the path. The center wave deals physical damage to enemy Champion icon.png champions hit.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Classic',
        'ecIeXGWnFuE'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'Prestige True Damage',
        'alH3oWU0oR4'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'True Damage',
        '3cFJPi_iTo0'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201

@data.route('/fill2')
def fill2():
    champ = Champion('Lux')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 2
    
    ability1 = Ability(
        champion_id,
        'Light Binding',
        'ACTIVE: Lux releases a sphere of light in the target direction that deals magic damage to the first two enemies hit and Root icon.png roots them for 2 seconds.',
        'COST: 50 MANA COOLDOWN: 11 / 10.5 / 10 / 9.5 / 9'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Prismatic Barrier',
        'ACTIVE: Lux launches her wand in the target direction which returns to her after reaching maximum range..',
        'COST: 60 MANA COOLDOWN: 14 / 13 / 12 / 11 / 10'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Lucent Singularity',
        'ACTIVE: Lux sends an anomaly of twisted light to the target location for up to 5 seconds, granting Sight icon.png sight of the area and Slow icon.png slowing enemies within. Lucent Singularity can be recast at any time while it is in flight or within its duration, and does so automatically after its duration ends.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'Final Spark',
        'ACTIVE: Lux fires a massive laser of light in a line in the target direction that deals magic damage to all enemies hit and briefly Reveal icon.png reveals them as well as grants Sight icon.png sight of the surrounding area.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Space Grove',
        'khEBkz6A0oQ'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'Luna empress',
        'aQ-BErLhAoI'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'Dark cosmic',
        'ZE5GFeUs_Ug&t'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201


@data.route('/fill3')
def fill3():
    champ = Champion('Lucian')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 3
    
    ability1 = Ability(
        champion_id,
        'Piercing Light',
        'ACTIVE: Lucian fires a laser in a line in the direction of the target enemy, dealing physical damage to all enemies within.',
        'COST: 70 / 80 / 90 / 100 / 110 MANA - COOLDOWN: 15'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Ardent Blaze',
        'ACTIVE: Lucian fires a shot in the target direction that explodes in a cross pattern upon hitting an enemy or reaching the end of its path, dealing magic damage to enemies struck and granting Sight icon.png sight of the area for 1 second.',
        'COST: 50 / 55 / 60 / 65 / 70 MANA - COOLDOWN: 11'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Relentless Pursuit',
        'PASSIVE: Relentless Pursuits Cooldown reduction icon.png cooldown is reduced by 1 second for each Lightslinger Lightslinger shot landed, doubled to 2 seconds against enemy champions.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'The Culling',
        'ACTIVE: Lucian Channeling icon.png channels for up to 3 seconds, rapidly firing up to 22 (+ 1 per 4% critical strike chance) shots in the target direction. Each shot deals physical damage to the first enemy hit, doubled against Minion icon.png minions. The Culling can be recast after 0.75 seconds during the channel, and does so automatically when the channel ends.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Arcania',
        'oQK8n12Zh4E'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'High Noon',
        'dXsTAfgG7nU'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'Demacia vice',
        '3Q0wmVE3ozs'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201

@data.route('/fill4')
def fill4():
    champ = Champion('Sett')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 4
    
    ability1 = Ability(
        champion_id,
        'Knuckle Down',
        'ACTIVE: Sett empowers his next two basic attacks within 5 seconds to gain Range icon.png 50 bonus range and deal bonus physical damage, capped at 400 total damage of each attack against',
        'COST: 50 MANA COOLDOWN: 11 / 10.5 / 10 / 9.5 / 9'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Haymaker',
        'PASSIVE: Sett stores 100% of post-mitigation damage taken as Grit on his resource bar, up to 50% of his Health icon.png maximum health. Each instance of stored Grit decays by 30% every second after 4 seconds.',
        'COST: 60 MANA COOLDOWN: 14 / 13 / 12 / 11 / 10'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Facebreaker',
        'ACTIVE: Sett Airborne icon.png pulls in enemies at his front and back in the target direction, dealing them physical damage and Slow icon.png slowing them by 50% for 0.5 seconds.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'The Show Stopper',
        'ACTIVE: Sett Suppression icon.png suppresses and True Sight icon.png reveals the target enemy Champion icon.png champion and Dash.png dashes with Unstoppable icon.png displacement immunity to their location, Yuumi You and Me!.png attaching them to himself on arrival and carrying them another 600 units in the same direction. Upon completing the dash, Sett slams the target into the ground, creating a massive shockwave at the impact area and quickly slides another 250 units beyond the impact location.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Pool Party',
        'F4ERA9oYlZc'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'Obsidian Dragon',
        'E7AIJn--_Hw'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'Mecha Kingdoms',
        '0vJWsu08iME'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201

@data.route('/fill5')
def fill5():
    champ = Champion('Ezreal')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 5
    
    ability1 = Ability(
        champion_id,
        'Mystic Shot',
        'ACTIVE: Ezreal fires a bolt of energy in the target direction that deals physical damage to the first enemy hit and applies On-hit icon.png on-hit and Lulu Pix, Faerie Companion.png on-attack effects at 100% effectiveness.',
        'COST: 50 MANA COOLDOWN: 11 / 10.5 / 10 / 9.5 / 9'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Essence Flux',
        'ACTIVE: Ezreal fires an orb in the target direction that marks the first enemy Champion icon.png champion, epic Monster icon.png monster, or structure hit for 4 seconds.',
        'COST: 60 MANA COOLDOWN: 14 / 13 / 12 / 11 / 10'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Arcane Shift',
        'ACTIVE: After the cast time, Ezreal Flash.png blinks from his current location up-to 475 units towards the target location, firing a homing bolt that deals magic damage to the nearest enemy and briefly Reveal icon.png reveals them.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'Trueshot Barrage',
        'ACTIVE: Ezreal fires an energy projectile in the target direction, which briefly grants Sight icon.png sight of the area it flies through and deals magic damage to enemies hit.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Pulsefire',
        'h8f-Pd0HXb8'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'PsyOps',
        'zor3QF7Mg08'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'Battle Academia',
        'tRmdh3sW5UA'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201

@data.route('/fill6')
def fill6():
    champ = Champion('Kayn')
    db.session.add(champ)
    db.session.commit()
    
    champion_id = 6
    
    ability1 = Ability(
        champion_id,
        'Reaping Slash',
        'ACTIVE: Kayn Dash.png dashes in the target direction, dealing physical damage to enemies he passes through, before swinging his scythe, dealing the same damage to surrounding enemies.',
        'COST: 50 MANA COOLDOWN: 11 / 10.5 / 10 / 9.5 / 9'
    )
    db.session.add(ability1)
    db.session.commit()
    
    ability2 = Ability(
        champion_id, 
        'Blades Reach',
        'ACTIVE: Kayn performs an upwards sweep with his scythe in the target direction, dealing physical damage to all enemies within a line and Slow icon.png slowing them by 90% decaying over 1.5 seconds.',
        'COST: 60 MANA COOLDOWN: 14 / 13 / 12 / 11 / 10'
    )
    db.session.add(ability2)
    db.session.commit()
    
    ability3 = Ability(
        champion_id,
        'Shadow Step',
        'ACTIVE: Kayn gains Movement speed icon.png 40% bonus movement speed, Ghost.png ghosting and the ability to ignore terrain collision for a duration. If Kayn has been in combat with enemy champions within the last 3 seconds, Shadow Step will instead last 1.5 seconds.',
        'COST: 70 MANA - COOLDOWN: 26 / 24.5 / 23 / 21.5 / 20'
    )
    db.session.add(ability3)
    db.session.commit()
    
    ability4 = Ability(
        champion_id,
        'Umbral Trespass',
        'ACTIVE: Kayn Shaco Hallucinate.png vanishes and Dash.png dashes to a marked enemy Champion icon.png champion. Upon arrival, he Channeling icon.png channels for up to 2.5 seconds, Yuumi You and Me!.png attaching to the target and True Sight icon.png revealing them. Umbral Trespass can be recast after 0.75 seconds during the channel, and does so automatically if the channel ends without reactivation or is Silence icon.png interrupted.',
        'COST: 100 MANA - COOLDOWN: 160 / 140 / 120'
    )
    db.session.add(ability4)
    db.session.commit()
    
    skin1 = Skin(
        champion_id,
        'Odyssey',
        'URo13CII05Y'
    )
    db.session.add(skin1)
    db.session.commit()
    
    skin2 = Skin(
        champion_id,
        'Nightbringer',
        'BufynU8zu2I'
    )
    db.session.add(skin2)
    db.session.commit()
    
    skin3 = Skin(
        champion_id,
        'Soul Hunter',
        'QWsyxpCin2M'
    )
    db.session.add(skin3)
    db.session.commit()
    
    return 'Done', 201