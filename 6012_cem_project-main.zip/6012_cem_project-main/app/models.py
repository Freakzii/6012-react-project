from . import db
#Champion ID skins and abilities
class Champion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    
    builds = db.relationship('Build', backref='champion', lazy=True)
    abilities = db.relationship('Ability', backref='champion', lazy=True)
    skins = db.relationship('Skin', backref='champion', lazy=True)
    
    def __init__(self, name):
        self.name = name
        
        
 #champion skins youtube ID     
class Skin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    yt_id = db.Column(db.String(50))
    champion_id = db.Column(db.Integer, db.ForeignKey('champion.id'), nullable=False)
     
    def __init__(self, champion_id, name, yt_id):
        self.name = name
        self.yt_id = yt_id
        self.champion_id = champion_id
#information for abilities
class Ability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    desc = db.Column(db.String(50))
    cost = db.Column(db.String(50))
    champion_id = db.Column(db.Integer, db.ForeignKey('champion.id'), nullable=False)
     
    def __init__(self, champion_id, name, desc, cost):
        self.name = name
        self.desc = desc
        self.cost = cost
        self.champion_id = champion_id
    #all builds for each champion are stored
class Build(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    champion_id = db.Column(db.Integer, db.ForeignKey('champion.id'), nullable=False)
    mythic = db.Column(db.String(50))
    rune1 = db.Column(db.String(50))
    rune2 = db.Column(db.String(50))
    starter = db.Column(db.String(50))

    summoner1 = db.Column(db.String(50))
    summoner2 = db.Column(db.String(50))
    
    def __init__(self, champion_id, mythic, starter, rune1, rune2, summoner1, summoner2):
        self.champion_id = champion_id
        self.mythic = mythic
        self.rune1 = rune1
        self.rune2 = rune2
        self.starter = starter

        self.summoner1 = summoner1
        self.summoner2 = summoner2
        

