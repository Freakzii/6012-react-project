from flask import Blueprint, jsonify, request
from . import db
from .models import Build, Champion, Ability, Skin
from flask_cors import CORS

main = Blueprint('main', __name__)
CORS(main, supports_credentials=True)
#how builds are added to database
@main.route('/add_build', methods=['POST'])
def add_build():
    build_data = request.get_json()
    print(build_data)
    new_build = Build(build_data['champion_id'], build_data['mythic'], build_data['starter'], build_data['rune1'],build_data['rune2'],build_data['summoner1'],build_data['summoner2'])
    db.session.add(new_build)
    db.session.commit()
    return 'Done', 201
#how builds are called from database
@main.route('/builds')
def builds():
    build_list = Build.query.all()
    builds = []
    
    for build in build_list:
        builds.append({'id' : build.id, 'id2' : build.champion_id, 'mythic' : build.mythic, 'rune1' : build.rune1, 'rune2' : build.rune2, 'starter' : build.starter, 'summoner1' : build.summoner1, 'summoner2' : build.summoner2 })

    champion_list = Champion.query.all()
    champions = []
    
    for champion in champion_list:
        champions.append({'id' : champion.id, 'name' : champion.name})

    return jsonify ({'builds': builds, 'champs': champions})
#how Champions are called from database
@main.route('/champions')
def champions():
    champion_list = Champion.query.all()
    champions = []
    
    for champion in champion_list:
        champions.append({'id' : champion.id, 'name' : champion.name})

    return jsonify ({'champs': champions})
#how specific builds are called from database
@main.route('/builds/<champID>')
def buildsFor(champID):
    build_list = Build.query.filter_by(champion_id=champID)
    builds = []
    


    for build in build_list:
        builds.append({'id' : build.id, 'id2' : build.champion_id, 'mythic' : build.mythic, 'rune1' : build.rune1, 'rune2' : build.rune2, 'starter' : build.starter, 'summoner1' : build.summoner1, 'summoner2' : build.summoner2 })
        
    return jsonify ({'builds': builds})
#how champions builds are called from database
@main.route('/champions/<champID>')
def getChampion(champID):
    champ_data = Champion.query.filter_by(id=champID).first()
    champ = {'id' : champ_data.id, 'name' : champ_data.name}

        
    return jsonify ({'champion': champ})
#how abilities are called from database
@main.route('/abilities/<champID>')
def abilitiesFor(champID):
    ability_list = Ability.query.filter_by(champion_id=champID)
    abilities = []
    


    for ability in ability_list:
        abilities.append({'id' : ability.id, 'id2' : ability.champion_id, 'name' : ability.name, 'desc' : ability.desc, 'cost' : ability.cost })
        
    return jsonify ({'abilities': abilities})
#how specific skins are called from database
@main.route('/skins/<champID>')
def skinsFor(champID):
    skin_list = Skin.query.filter_by(champion_id=champID)
    skins = []
    
    for skin in skin_list:
        skins.append({'id' : skin.id, 'id2' : skin.champion_id, 'name' : skin.name, 'yt_id' : skin.yt_id})
        
    return jsonify ({'skins': skins})